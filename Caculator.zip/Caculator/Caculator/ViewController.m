//
//  ViewController.m
//  Caculator
//
//  Created by Yinchuan Zhou on 3/28/16.
//  Copyright © 2016 Yinchuan Zhou. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@end

@implementation ViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)DigitalNumber:(UIButton *)sender

 {
     
     NSMutableString*str= [[NSMutableString alloc]init];
     [str appendString:_numberDisplay.text];
     
     [str appendString:sender.currentTitle];
     _numberDisplay.text=str;
     
     
     NSString*firstNumber=[[NSString alloc]init];
     NSString*str2=[[NSString alloc] init];
     NSString*secondeNumber=[[NSString alloc]init];
     char symbol='0';
     float total=0;
     float firstValue=0;
     int firstIndex=0;
     NSLog(@"str length%lu",(unsigned long)[str length]);
     NSLog(@"str value %@",str);
     NSLog(@"lable value%@",_numberDisplay.text);
     

     for (short index=0; index<[str length]; index++)
     {
         if ([str characterAtIndex:index]=='+'||[str characterAtIndex:index]=='-'||[str characterAtIndex:index]=='*'||[str characterAtIndex:index]=='/'||[str characterAtIndex:index]=='%')
         {
             firstIndex=index;
             symbol=[str characterAtIndex:index];
             NSLog(@"first number %c",symbol);

             firstNumber= [str substringToIndex:index];
             NSLog(@"first number %@",firstNumber);
             firstValue=[_numberDisplay.text floatValue];
             
             NSLog(@"curent char%c",[str characterAtIndex:index]);
            
             NSLog(@"first value%f",firstValue);
         }
         
         
        if ([str characterAtIndex:index]=='=')
         {
             str2=[str substringToIndex:index];
             NSLog(@"str2 %@",str2);
             
             
             secondeNumber=[str2 substringFromIndex:firstIndex+1];
             NSLog(@"secondnumber %@",secondeNumber);

             
             float secondValue=[secondeNumber floatValue];
             if (symbol=='+') {
                 
                 
                 total=(float)(firstValue+secondValue);
                 
             } else if(symbol=='-') {
                 
                 
                 total=firstValue-secondValue;
             } else if(symbol=='*') {
                 
                 
                 total=firstValue*secondValue;
             } else if (symbol=='/') {
                 
                 
                 total=firstValue/secondValue;
                 
                 
             }else if (symbol=='%') {
                 
                 
                 total=(int)firstValue%(int)secondValue;
                 

             
         }
             
             _numberDisplay.text=[NSString stringWithFormat:@"%.2f", total];
             NSLog(@"total %f",total);


    }
         
         if ([str characterAtIndex:index]=='C') {
             _numberDisplay.text=@"";
         }
         
     }
 
 }
@end


