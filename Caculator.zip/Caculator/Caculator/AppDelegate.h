//
//  AppDelegate.h
//  Caculator
//
//  Created by Yinchuan Zhou on 3/28/16.
//  Copyright © 2016 Yinchuan Zhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

